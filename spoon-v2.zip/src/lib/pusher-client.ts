"use client";
import PusherJs from "pusher-js";

let pusherClient: PusherJs | null = null;

export function getPusherClient(): PusherJs {
  if (!pusherClient) {
    pusherClient = new PusherJs(process.env.NEXT_PUBLIC_PUSHER_KEY!, {
      cluster: process.env.NEXT_PUBLIC_PUSHER_CLUSTER || "eu",
    });
  }
  return pusherClient;
}
